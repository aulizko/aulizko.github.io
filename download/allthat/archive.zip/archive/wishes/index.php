<?php 
    echo 'allThat.Bookmarklet.' . $_GET['callback'] . '(null);';
?>