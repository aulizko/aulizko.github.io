<?php

    function generateBookmarkletCode ($user_hash, $server_address) {
        $bookmarklet_address_code = "javascript:(function(){var a = window.allThat={userId:'" . $user_hash;

        $bookmarklet_address_code .= "',server:'" . $server_address;

        $bookmarklet_address_code .= "',css:document.createElement('link'),script:document.createElement('script')},h=document.getElementsByTagName('head')[0];a.css.rel='stylesheet';a.css.href=a.server+'css/bookmarklet.3.css';h.appendChild(a.css);a.script.src=a.server+'js/bookmarklet.4.js';h.appendChild(a.script);h=null;})()";
        
        echo $bookmarklet_address_code;
    }
?>

