(function () {
    var a = window.allThat = {
        userId : '1231lfdjvr12',
        server : 'http://allthat.local:8888/',
        css : document.createElement('link'),
        script : document.createElement('script')
    },
    h = document.getElementsByTagName('head')[0];
    a.css.rel='stylesheet';
    a.css.href=a.server+'css/bookmarklet.2.css';
    h.appendChild(a.css);
    a.script.src=a.server+'js/bookmarklet.3.js?userId='+a.userId;
    h.appendChild(a.script);
    h=null;
})();