<?php
    require_once('bookmarklet_code_generator.php');
    $user_hash = "1231lfdjvr12";
    $server_address = "http://allthat.local:8888/";
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
    <head>
        <meta http-equiv="Content-type" content="text/html; charset=utf-8">
        <title>bookmarklet test</title>
    </head>
    <body>
        <p>This is standard page which we can choose somewhere here. Please, click <a href="<?php generateBookmarkletCode($user_hash, $server_address); ?>">here</a>.</p>
    </body>
</html>