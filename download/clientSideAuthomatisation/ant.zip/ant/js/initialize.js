$(function () {
    $('body').append('<p>Private variable == ' + some_object.getPrivateVariable() + '</p>');
});