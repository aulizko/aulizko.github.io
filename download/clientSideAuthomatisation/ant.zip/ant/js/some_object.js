var some_object = function () {
    var private_variable = 5;
    
    return {
        getPrivateVariable : function () {
            return private_variable;
        }
    };
}();